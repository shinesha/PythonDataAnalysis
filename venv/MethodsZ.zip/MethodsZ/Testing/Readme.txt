1/ I took the first 30 rows from the input file.
This is called inputFileForTesting.csv
I ran that through the code. 

2/ This generated 
intersectionTest.csv  which is post codes intersecting with London Postcodes - 11 rows
inputFilePostCodeErrorsTest.csv - all the none valid post codes - 7 rows
allValidPostCodesTest.csv - all the valid post code is 12 rows

11+ 7 + 12 = 30 

3/ inputFileForTestingChecking.csv
is a copy of inputFileForTesting.csv for manual checking
Column D
Lo is for values that appear in intersection file
e is for values that appear in the error file 
v is for valid postcode

